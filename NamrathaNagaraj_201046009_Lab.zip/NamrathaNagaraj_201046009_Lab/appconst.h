#ifndef APPCONST_H_INCLUDED
#define APPCONST_H_INCLUDED

#define QUEUE_MAX_DEPTH 5
#define SHARE_NAME      32
#define SHARE_OK        1
#define SHARE_EMPTY     2
#define SHARE_FULL      3
#define Q_LEN           32



#endif // APPCONST_H_INCLUDED
