#include <stdio.h>
#include <stdlib.h>
#include  "trading.h"
#include  "trading.c"
#include  <assert.h>

void test_

int main()
{
    return 0;
}
